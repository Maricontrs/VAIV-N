## Example GDPR consent dialog

1. Add dependency into [`build.gradle`](./build.gradle#L17)
2. Integrate it within [Activity](./src/main/java/com/example/app/MainActivity.java#L51)

![screenshot](./screenshot.png?raw=true)
